const FirebaseConstants = {
	KEY: "YOUR_API_KEY"
}

export default FirebaseConstants;