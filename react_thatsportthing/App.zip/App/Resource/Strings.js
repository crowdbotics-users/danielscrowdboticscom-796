const Strings = {
  allphotosvideo: "All Photos and Videos",
  albums: "Albums",
  tagged: "Tagged",
};

export default Strings;
